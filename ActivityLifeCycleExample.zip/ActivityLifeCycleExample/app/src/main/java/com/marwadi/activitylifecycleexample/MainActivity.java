package com.marwadi.activitylifecycleexample;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

{


            setContentView(R.layout.activity_main);

            Toast.makeText(this,"onCreate",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onCreate");


        }


 {
            super.onStart();
            Toast.makeText(this,"onStart",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onStart");
        }

{
            super.onResume();
            Toast.makeText(this,"onResume",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onResume");
        }


 {
            super.onRestart();
            Toast.makeText(this,"onRestart",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onRestart");
        }

{
            super.onStop();
            Toast.makeText(this,"onStop",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onStop");
        }
 {
            super.onDestroy();
            Toast.makeText(this,"onDestroy",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onDestroy");
        }
        {
            super.onPause();
            Toast.makeText(this,"onpause",Toast.LENGTH_SHORT).show();
            Log.d("Lifecycle","onpause");
        }
    }
    }
