package com.marwadi.asynctask;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

public class AsyncData extends AsyncTask<String, Integer, String> {

    @SuppressLint("StaticFieldLeak")
    Context localContext;

    AlertDialog.Builder builder;

    // Constructor
    public AsyncData(Context globalContext) {
        this.localContext = globalContext;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        builder = new AlertDialog.Builder(localContext);
    }

    @Override
    protected String doInBackground(String... strings) {
        String data = strings[0];

        try {
            Thread.sleep(2000); // simulate delay
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return data; // return result properly
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        builder.setMessage(result)
                .setTitle("AsyncTask Example")
                .setCancelable(true)
                .setIcon(R.drawable.ic_launcher_background)
                .show();
    }
}