package com.marwadi.explicitintent_ex;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button b_register,b_login;
    EditText e_user,e_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        b_login = findViewById(R.id.m_b_login);
        b_register = findViewById(R.id.m_b_register);

        e_user = findViewById(R.id.m_e_username);
        e_pass = findViewById(R.id.m_e_password);
//creating listener
        //its a lambda click listener
        b_login.setOnClickListener(view -> {
//Get data from edit text
            String user = e_user.getText().toString();
            String pass = e_user.getText().toString();


            if (user.equals("tulsi"))
            {
                //creating Intent
                Intent data  = new Intent(MainActivity.this,dashboard.class);
                //passing data with intent to dashboard activity
                data.putExtra("user",user);
                data.putExtra("pass",pass);
                //calling activity
                startActivity(data);

            }
        else {
                Toast.makeText(this,"wrong username",Toast.LENGTH_SHORT).show();
            }



        });
    }
}