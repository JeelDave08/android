package com.example.fragementexample;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class One extends Fragment {

    Button f_o_b_data;
    View view;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

       view = inflater.inflate(R.layout.fragment_one, container, false);


        f_o_b_data = view.findViewById(R.id.f_o_b_data);
        f_o_b_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(view.getContext(), "This is from fragment One", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}